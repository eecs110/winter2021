'''
Here is some starter code. I will do the first part of the first exercise for you:
'''

# Exercise 1:
print('*******************')

# Exercise 2:


# Exercise 3:


# Exercise 4:


# Exercise 5:


# Exercise 6:


# Exercise 7:


# Exercise 8:


# Exercise 9:
