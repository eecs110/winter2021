# Write a program that dynamically creates a "TODO" list on-the-fly.
# You will ask the user what they need to do, and store it in a list.
# Do this 5 times, and at the end of the program, print out the list.