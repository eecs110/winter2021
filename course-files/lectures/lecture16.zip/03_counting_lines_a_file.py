import utilities
f = open(utilities.get_file_path('moby_dick.txt'), 'r', encoding='utf8')

# Your job: can you write some code to
# count how many lines there are in the file?

# print('there are ', ?????, 'lines in the file.')