'''
INSTRUCTIONS: Update this function as follows:
If only red is turned on, return red.
If only yellow is turned on, return yellow.
If only blue is turned on, return blue.
If only red and yellow are both turned on, return orange.
If only red and blue are turned on, return purple.
If only yellow and blue are turned on, return green.
If everything is turned on, return black.
'''

def get_color(red_switch:bool, green_switch:bool, blue_switch:bool):
    '''
    Given the following switches, this function will return the
    correct color
    '''

    