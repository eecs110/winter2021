def even_or_odd(num):
    if num % 2 == 0:
        return 'even'
    else:
        return 'odd'
print('5:', even_or_odd(5))
print('10:', even_or_odd(10))
print('11:', even_or_odd(11))
print('18:', even_or_odd(18))
