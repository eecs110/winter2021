names = ['Larry', 'Curly', 'Moe', 'Seamus']

# write a while loop that prints every item in the names list:
counter = 0
while counter < len(names):
     print(names[counter])
     counter += 1