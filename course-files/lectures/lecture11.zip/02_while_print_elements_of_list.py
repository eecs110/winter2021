names = ['Larry', 'Curly', 'Moe', 'Seamus']

# write a while loop that prints every item in the names list:
