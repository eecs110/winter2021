colors = ['#ebbab9', '#c9c5ba', '#97b1a6', '#698996', '#407076']

# print each color: while loop:
counter = 0
while counter < len(colors):
    print(colors[counter])
    counter += 1

# for loop syntax:
# for color in colors:
#     print(color)
