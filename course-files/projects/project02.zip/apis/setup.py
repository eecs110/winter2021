from setuptools import setup, find_packages
setup(name="apis", packages=find_packages())